Opening agap file
gcc --std=gnu99 -o movie .\main.c
./movie .\movie_sample_1.csv 