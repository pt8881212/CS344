/*
// Pratiksha Aga
// CS 344 
// Assignment 1
*/

#include <stdio.h> // lib used for input and output 
#include <stdlib.h> // lib used for functions involving memory allocation
#include <string.h> // lib used for strings

/* struct for movie information */
struct movie // movie is name of struct 
{
    // defined
    char *title; 
    int year;
    char *language;
    double rating_value;
    struct movie *next;
};

/* Parse the current line which is space delimited and create a
*  movie struct with the data in this line
*/
struct movie *createMovie(char *currLine)
{
    struct movie *currMovie = malloc(sizeof(struct movie));

    // For use with strtok_r
    char *saveptr;

    // The first token is the title
    char *token = strtok_r(currLine, ",", &saveptr);
    currMovie->title = calloc(strlen(token) + 1, sizeof(char));
    strcpy(currMovie->title, token);

    // The next token is the year
    token = strtok_r(NULL, ",", &saveptr);
    currMovie->year = atoi(token); // string to int

    // The next token is the language
    token = strtok_r(NULL, ",", &saveptr);
    currMovie->language = calloc(strlen(token) + 1, sizeof(char));
    strcpy(currMovie->language, token);

    // The last token is the rating value
    token = strtok_r(NULL, "\n", &saveptr);
    char *ptr;
    currMovie->rating_value = strtod(token, &ptr); 

    // Set the next node to NULL in the newly created movie entry
    currMovie->next = NULL;

    return currMovie;
}

/*
* Return a linked list of movie by parsing data from
* each line of the specified file.
*/
struct movie *processFile(char *filePath)
{
    // Open the specified file for reading only
    FILE *movieFile = fopen(filePath, "r"); // able to open any csv file 

    char *currLine = NULL; // set current line to null
    size_t len = 0;
    ssize_t nread;
    char *token;

    // The head of the linked list
    struct movie *head = NULL;
    // The tail of the linked list
    struct movie *tail = NULL;

    // Reading the file line by line
    while ((nread = getline(&currLine, &len, movieFile)) != -1){
        // Get a new movie node corresponding to the current line
        struct movie *newNode = createMovie(currLine);

        // Is this the first node in the linked list?
        if (head == NULL)
        {
            // This is the first node in the linked link
            // Set the head and the tail to this node
            head = newNode;
            tail = newNode;
        }
        else
        {
            // This is not the first node.
            // Add this node to the list and advance the tail
            tail->next = newNode;
            tail = newNode;
        }
    }
    free(currLine);
    fclose(movieFile);
    return head;
}



/*
* Print the linked yearMovie of movie
*/
void printMovieList(struct movie *yearMovie, int userInputY){ // this function yearMovie reads from top to bottom
    int movieFound = 0; // setting the movie found to zero

    while (yearMovie != NULL){ // while the movie year yearMovie is not equal to 0 then keep reading the next line 
        if(yearMovie->year == userInputY){ // if whatever the user enters and it is equal to csv file in column year
            printf("%s\n",yearMovie->title); // prints the movies titles of that year
            movieFound = 1; // if the movie is found (true)
        }
        yearMovie = yearMovie->next; // goes to the movie list and goes to the next and lists them 
    }
     // finish the while loop here so the message isn't being displayed along with the user input 
        if(movieFound == 0) // if the movie is not found in that year then 
        printf("No data about movie releases in the year %d", userInputY);   // display this message, along with the year the user searched for     
       
}


void printRateList(struct movie *rateList){ // function for rate value 
    int i; // used in for loop 
    for(i = 1000; i <= 2021; i++){ // start the "year date" from 1000, then the year has to be 2021 or less, since no movies are released yet. 
        // go through this loop until any year rating is matched 
        struct movie *current = rateList; // setting the current rate to pointer ratelist 
        struct movie *maximum = NULL; // setting the max rating value to missing value aka no value 
        struct movie *tmp = rateList; // tmp = temporary hold
        struct movie *rate = NULL; // setting the rate to no value 
        while(current != NULL){ // until there is nothing go through this loop 
            if(current->year == i){ // if the year matches with the for loop then do this 
                rate = current; // assigning current to rate
                while(rate != NULL){ // if the rate is not equal to no value than do this 
                    if(rate->rating_value >= current->rating_value){ // rate pointing to rating value in csv file and if it is 
                        maximum = current; //greater than or equal to the current rating value then assign the current to the max

                    }
                        else if(rate->rating_value < current->rating_value){ // if the rate is less than, still assign from current to max 
                        maximum = current;
                    }
                

                rate = rate->next; // going through the csv file 
            } 
            printf("%d, %.2f, %s \n",  // printing from double, to .2 gives us 2 sig figs , then prints the strings 
            maximum->year, // puts the max of year 
            maximum->rating_value,  // puts max of rating 
            maximum->title); // puts max of title 
            break;
            }
            else if (current->year != i) current = current->next; 
        }
    }
    
}


void printLanguage(struct movie *listlang){ // print language function 
    struct movie *current = NULL; // setting current info to no value 
    char *word[100]; // array of words 
  
    printf("Enter the language for which you want to see movies for: "); // print message
    scanf("%s", word); //user inputs a string

    current = listlang; // list lang is now assigned to current 

    while(current != NULL){ // if the current is not equal to no value then
        if(strstr(current->language, word))// using strstr for finding the first occurence of the substring 
        printf("%d %s\n", current->year, current->title); // prints the year and the title 
        
        current = current->next; // going through the list of all movies 
               

    }

}




int display(struct movie* movie){
    int userInput; // to use in switch statement 
    int year; //to use in print movie function 
    int rate;
    char lang;
    int repeat = 1;

    do{ 
    // prints the statements 
        printf("1. Show movies released in the specified year\n");
        printf("2. Show highest rated movie for each year\n");
        printf("3. Show the title and year of release of all movies in a specific language\n");
        printf("4. Exit from the program\n");
        scanf("%d",&userInput); // takes the input of the user and stores it in userInput
    
        switch(userInput){ // user input is taken and put into switch statement, and depending on that the program will execute. 
            case 1: printf("Enter the year for which you want to see movies: \n");
                    scanf("%d",&year); // takes user input and stores it in year
                    printf("\n"); // space 
                    printMovieList(movie,year); // calling function print movie list with the struct and the int parameters
                    printf("\n"); // space 
                break;    
            case 2: printRateList(movie); // function for rate 
                    printf("\n");
                    break;
            case 3: printLanguage(movie); // functiong for language 
                    printf("\n");
                    break;
            default: repeat = 0; // to quit the program 
        }
    }
    while(repeat); // repeating the program 
         
}

