
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // string library 
#include "agap.c"



int main(int argc, char *argv[])
{
    int movieNumber;
    if (argc < 2)
    {
        printf("You must provide the name of the file to process\n");
        printf("Example usage: ./movie movie_sample_1.csv\n");
        return EXIT_FAILURE;
    }
    
    struct movie *movie = processFile(argv[1]);
    printf("Processed file %s and parse data for %d movies \n", argv[1], movieNumber);
    display(movie);
    return EXIT_SUCCESS;
   
}