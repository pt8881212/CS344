Compiling agap file 
gcc --std=gnu99 -o movies_by_year main.c

large file is movies_sample1.csv
small file is movies_sample_2.csv
