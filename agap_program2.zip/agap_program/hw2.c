/*
// Pratiksha Aga
// CS 344 
// Assignment 2
*/

#include <stdio.h> // lib used for input and output 
#include <stdlib.h> // lib used for functions involving memory allocation
#include <string.h> // lib used for strings
#include <dirent.h> // directory stream
#include <time.h> // size_t
#include <sys/types.h> // for off_t as well as file size
#include <sys/stat.h> // mkdir
#include <unistd.h> // x open


/* struct for movie information */
struct movie // movie is name of struct 
{
    // defined
    char *title; 
    int year;
    char *language;
    double rating_value;
    struct movie *next;
};

/* Parse the current line which is space delimited and create a
*  movie struct with the data in this line
*/
struct movie *createMovie(char *currLine)
{
    struct movie *currMovie = malloc(sizeof(struct movie));

    // For use with strtok_r
    char *saveptr;

    // The first token is the title
    char *token = strtok_r(currLine, ",", &saveptr);
    currMovie->title = calloc(strlen(token) + 1, sizeof(char));
    strcpy(currMovie->title, token);

    // The next token is the year
    token = strtok_r(NULL, ",", &saveptr);
    currMovie->year = atoi(token); // string to int

    // The next token is the language
    token = strtok_r(NULL, ",", &saveptr);
    currMovie->language = calloc(strlen(token) + 1, sizeof(char));
    strcpy(currMovie->language, token);

    // The last token is the rating value
    token = strtok_r(NULL, "\n", &saveptr);
    char *ptr;
    currMovie->rating_value = strtod(token, &ptr); 

    // Set the next node to NULL in the newly created movie entry
    currMovie->next = NULL;

    return currMovie;
}

/*
* Return a linked list of movie by parsing data from
* each line of the specified file.
*/
struct movie *processFile(char *filePath)
{
    // Open the specified file for reading only
    FILE *movieFile = fopen(filePath, "r"); // able to open any csv file 

    char *currLine = NULL; // set current line to null
    size_t len = 0;
    ssize_t nread;
    char *token;

    // The head of the linked list
    struct movie *head = NULL;
    // The tail of the linked list
    struct movie *tail = NULL;

    // Reading the file line by line
    while ((nread = getline(&currLine, &len, movieFile)) != -1){
        // Get a new movie node corresponding to the current line
        struct movie *newNode = createMovie(currLine);

        // Is this the first node in the linked list?
        if (head == NULL)
        {
            // This is the first node in the linked link
            // Set the head and the tail to this node
            head = newNode;
            tail = newNode;
        }
        else
        {
            // This is not the first node.
            // Add this node to the list and advance the tail
            tail->next = newNode;
            tail = newNode;
        }
    }
    free(currLine);
    fclose(movieFile);
    return head;
}





// search for small file function 

struct dirent *smallFile(){
    DIR* checkDir; // holds the directory we are starting in 
    char targetFilePrefix[32] = "movies_"; // prefix we're looking for (from slide 1:30, week 3)
    char newestDirName[256]; // holds the name of the newest dir that contains prefix
    struct dirent *fileIndir; // holds the current subir of the starting dir(week 3 slide 30)
    struct dirent *tempFile;
    struct dirent *smFile;
    struct stat dirAttributes; // holds information we've gained about subdir
    struct stat temporaryAttribute;


    checkDir = opendir("."); // open up the directory this program was run in

    if(checkDir > 0){ // make sure the current directory could be opened
        while((fileIndir = readdir(checkDir)) != NULL){ // check each entry in directory
            if(strstr(fileIndir->d_name,targetFilePrefix) != NULL && strstr(fileIndir->d_name, ".csv") != NULL){ // if entry has prefix
                stat(fileIndir->d_name, &dirAttributes); // get attributes of the entry
                off_t i = dirAttributes.st_size; //file size 
                tempFile = fileIndir; // assign to tempfile
                while((tempFile = readdir(checkDir)) != NULL){ // check each entry in directory
                    if(strstr(tempFile->d_name, targetFilePrefix) != NULL && strstr(tempFile->d_name, ".csv") != NULL){ // if entry has prefix
                        stat(tempFile->d_name, &temporaryAttribute); // get attributes of the entry
                        off_t j = temporaryAttribute.st_size; // file size
                        if( j >= i){ // if temporary attri is greater than original attribute then
                            smFile = fileIndir; // assign to small file
                        }
                        else if(j < i){ // or else 
                            smFile = tempFile; // assign the temp file to small file 
                        }
                    }
                }
            }
        }

        printf("\n Now processing the chosen file named %s \n", smFile->d_name);
        return smFile;
        closedir(checkDir); // close the directory we opened
    }


}

struct dirent *largeFile(){
    DIR* checkDir; // holds the directory we are starting in 
    char *fileName;
    char targetFilePrefix[32] = "movies_"; // prefix we're looking for (from slide 1:30, week 3)
    char newestDirName[256]; // holds the name of the newest dir that contains prefix
    struct dirent *fileIndir; // holds the current subir of the starting dir(week 3 slide 30)
    struct dirent *tempFile;
    struct dirent *bigFile;
    struct stat dirAttributes; // holds information we've gained about subdir
    struct stat temporaryAttribute;

    checkDir = opendir("."); // open up the directory this program was run in 

    if(checkDir > 0){  // make sure the current directory could be opened
        while((fileIndir = readdir(checkDir)) != NULL){ // check each entry in dir
            if(strstr(fileIndir->d_name, targetFilePrefix) != NULL && strstr(fileIndir->d_name, ".csv") != NULL){ // if entry has prefix
            stat(fileIndir->d_name, &dirAttributes); // get attributes of the entry
            off_t i = dirAttributes.st_size; // file size
            tempFile = fileIndir; // assign to temp file
                while((tempFile = readdir(checkDir)) != NULL){ // while loop for checking each entry in dir
                    if(strstr(tempFile->d_name, targetFilePrefix) != NULL && strstr(tempFile->d_name,".csv") != NULL){ // if entry has prefix
                        stat(tempFile->d_name, &temporaryAttribute);// get attributes of the entry (all from slide 30 week 3 code )
                        off_t j = temporaryAttribute.st_size; // assign file size to j
                            if(j >= i){ // if temp size is greater than or equal to original then
                                bigFile = tempFile; // assign temp to large file
                            }
                            else if(j < i){ // if otherwise then
                                bigFile = fileIndir; // assign file in dir to big file
                            }
                    }
                }
            }
        }

        printf("\n Now processing the chosen file name %s\n", bigFile->d_name);
        return bigFile;
    }
    closedir(checkDir); // close the directory we opeend 

}


// making sure the file exists 

struct dirent *existFile(char *file){
    DIR* checkDir; // holds the directory we are starting in
    struct dirent *fileInDir; // hold the current subdir of the starting file
    int exist = 0; // 1 is true, file is there, if 0 file isn't there 

    checkDir = opendir("."); // open up the directory this program was run in
        if(checkDir > 0){ // make sure the current directory could be opened
            while((fileInDir = readdir(checkDir)) != NULL){ //check each entry in dir
                if(strcmp(fileInDir->d_name, file) == 0){
                printf("File %s exists in current directory\n", fileInDir->d_name);
                exist = 1; // the file is there 
                return fileInDir;
                }
	    }
            if(exist == 0){ // if the file isn't there then 
                printf("File %s does not exist\n", file);
                return fileInDir = NULL;
            } 
    }    
    closedir(checkDir);
        
}

/*

https://stackoverflow.com/questions/308695/how-do-i-concatenate-const-literal-strings-in-c
function used from stackoverflow 
concatenate const/literal strings in C
*/

char *concat(char* string1, char string2[15]){
    char *string = malloc(strlen(string1) + strlen(string2) +1 );
    strcpy(string, string1);
    strcat(string, string2);

    return string;
}

// creating directory function 

char *createDir(){
    int value; // mkdir value that will be returned
    char stringnum[15]; // random number will be stored into stringnum
    srandom(time(NULL)); //random 
    

    long int num = random() % 100000; // for file number randomly done
    sprintf(stringnum, "%d", num); // int to string conversion

    char *dirName = concat("pratiksha.movies.",stringnum); // combining two strings 

    value = mkdir(dirName, 0750);
    if(value == 0){
        printf("Created directory with name: %s\n", dirName);
        return dirName;
    }
    else{
        printf("Unable to create directory\n");
        exit(1);
    }

}


// cerating file function 
void createFile(char *file){
    DIR* checkDir;
    char *dirName = createDir();

    struct movie *movie = processFile(file); // call processfile 
    FILE* fptr; // file pointer 
    char stringnum[15]; // store number in 


    checkDir = opendir(dirName); // opening dir 
    printf("\n Now processing the chosen file %s \n", file);

    if(checkDir > 0) {
        for(int i = 1000; i <= 9999; i++){
            struct movie* tmpo = movie; // assign movie to temporary
                while(tmpo != NULL){
                    if(tmpo->year == i){
                        sprintf(stringnum,"%d", i);
                        char *file1 = concat(dirName, "/"); // calling concat function into 
                        char *file2 = concat(stringnum, ".txt"); // calling concat function into
                        char* fileName = concat(file1,file2); // calling concat function into 
                        fptr = fopen(fileName,"a"); // append mode (so it does not overwrite)
                            if(fptr == NULL){ 
                                printf("Unable to create file %s.\n", fileName);
                                exit(1);
                            }
                            fprintf(fptr, "%s\n", tmpo->title); 
                            fclose(fptr);
                    
                        }
                        tmpo = tmpo->next;
                }
            }
        }

        // freeing movie 
        closedir(checkDir);    
        struct movie* tmp = NULL;
        while(movie != NULL){
            tmp = movie->next;
            free(movie->title);
            free(movie->language);
            movie = tmp;
        }
            free(movie);
}



void display(){
    int userInput;
    int repeat = 1; // repeat is true 
    int user;

    do{     
        // printing the info 
        int process = 1;
        printf("\n");
        printf("1. Select file to process\n");
        printf("2. Exit the program\n");
        printf("Enter a choice 1 or 2  "); 
        printf("\n");
        scanf("%d", &userInput); // gets user input 
        if(userInput == 1){ // if the user input is 1 then do 
            while(process == 1){
                char *fileName;
                struct dirent* smFile, *file, *bigFile; // all the struct for the file large and small
                // printing info 
                printf("Which file you want to process?\n");
                printf("Enter 1 to pick the largest file\n");
                printf("Enter 2 to pick the smallest file\n");
                printf("Enter 3 to specify the name of a file\n");
                scanf("%d", &user);

                if(user == 1){
                    bigFile = largeFile(); // large file function is called
                    createFile(bigFile->d_name);
                    process = 0; // false 
                }
                else if(user == 2){
                    smFile = smallFile(); // small file function is called
                    createFile(smFile->d_name);
                    process = 0; // false
                }
                else if(user == 3){ // file name
                    printf("Enter the complete file name: ");
                    scanf("%s", fileName);
                    file = existFile(fileName);
                    if(file == NULL){
                        process = 1; // true 
                    }                        
                    else if(file != NULL){ 
                    createFile(file->d_name);
                    process = 0;
                    }
                }

            }
        }
        else if(userInput == 2){ // exit the program 
            repeat = 0;
            exit(0);
        }

    }while(repeat);
}

    
