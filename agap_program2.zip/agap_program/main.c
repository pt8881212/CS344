#include <stdlib.h>
#include <string.h> 
#include "hw2.c" // homework 2 c file 
//
// int main function where the display function is called from
// 

int main()
{
    
    display(); // call display function where the program will start from 
    return 0;
   
}