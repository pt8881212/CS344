Compiling agap file 
gcc --std=gnu99 -o smallsh smallsh.c
