/*
Pratiksha Aga
CS 344 
Assignment 3
*/

#include <stdio.h> // for perror
#include <stdlib.h> // for exit
#include <string.h> // lib used for strings
#include <sys/types.h> // for pid_t
#include <unistd.h> // fork, execv
#include <signal.h> // signals
#include <fcntl.h> //file control option use fcntl()
#include <sys/wait.h> // pit_t wait returns the process id of the terminated child waitpid()

//shell must support command lines with a maximum length of 2048 characters
#define MAX 2048

int main(){
    //Support running commands in background processes
    int backgroundProcesses = 1;

     // user enters CTRL Z
    void zSIGTSTP(){
	    if (backgroundProcesses == 1){
		    char* f = "\nEntering foreground-only mode (& is now ignored)\n"; // assigned to f
		    write(STDOUT_FILENO, f, SIGRTMIN+24); // write data out of a buffer, sigrtmin+n n is a constant integer expression
		    fflush(stdin);	// flush out the output buffers each time you print, call fflush() immediately after each and every time you ouput text (f)
		    backgroundProcesses = 0; // false
	    }

	    else{
		    char* f = "\nExiting foreground-only mode\n";
		    write(1, f, SIGRTMIN-4);
		    backgroundProcesses = 1; // true
	    }
    }
    // A CTRL-C command from the keyboard sends a SIGINT signal to the parent process and all children at the same time (this is a built-in part of Linux).
	struct sigaction signalc = {{0}};
	signalc.sa_handler = SIG_IGN; // (source: https://man7.org/linux/man-pages/man2/sigaction.2.html )specifies the action to be associated with signum and may be sig_dfl 
    //for the default action, sig_ign to ignore this signal or pointer to a signal handling function 
    // receives the signal number as its only argument            
	signalc.sa_flags = 0; // specifies a set of flags which modify the behavior of the signal                 
	sigfillset(&signalc.sa_mask); // fill a signal set ,specifies a mask of signals which should be blocked 
	sigaction(SIGINT, &signalc, NULL); // ignore sigint

    
    //A CTRL-Z command from the keyboard sends a SIGTSTP signal to your parent shell process and all children at the same time (this is a built-in part of Linux).
    // source:  https://man7.org/linux/man-pages/man2/sigaction.2.html
	struct sigaction signalz = {{0}}; 
	signalz.sa_handler = zSIGTSTP; // when user enters control z, assign to signalz
	signalz.sa_flags = 0; // modify the behavior of the signal
	sigfillset(&signalz.sa_mask); // fill a signal set, specifies a mask of signals which should be blocked
	sigaction(SIGTSTP, &signalz, NULL); // ignore sigtstp 


    // child pid variable
	pid_t 	spawnpid = -5;  // code from lecture exploration: process api 
 	char 	str[MAX]; // take users string
	char    str_array[512][100]; // separate string to each words 
	char    homeDir[100]; // change home directory
	char *	str_args[512]; // support command lines with a maximum of 512 arguments 
	

    // source for pid_t to string https://stackoverflow.com/questions/53230155/converting-pid-t-to-string
    char pid[10];	
	sprintf(pid, "%d", getpid());

    // initializing variables 
	int repeat = 1; // for loop
	int exitNum = 0; // exit number for status
	int	totalPids = 0; // number of total pids 
	int	signal = 0; 
	int background = 0;
	do
    {
		int i,j,wordCount,charCount,redirection,childExit,openFile,result;

        /*
        User will see : on the screen when the program runs 
        */
		fflush(stdin);	//flush out the output buffers each time you print, call fflush() immediately after each and every time you ouput text (f)
		printf(": ");
		fgets(str, MAX, stdin); // from the global variable MAX reads input from user, need to provide input during runtime 
		str[strlen(str)-1] = '\0'; // taking the newline out of the string

		wordCount = 0; // user inputs word count assign to 0
		charCount=0; // number of characters assigned to 0


        /*
        for loop for replacing $$ 
        */
		for ( i = 0; i <= (strlen(str)); i++)
		{
			if(str[i] == '$' && str[i+1] == '$')
			{
				for(j = 0; j < strlen(pid); j++)
				{
					str_array[wordCount][charCount] = pid[j];
					charCount++;
				}
				i++;
			}
			else if(str[i] == ' ' || str[i] == '\0')
			{
				str_array[wordCount][charCount] = '\0';
				charCount = 0;
				wordCount++;
			}
			else if(str[i] == '&' && charCount == 0 && str[i+1] == '\0')
			{
				i = strlen(str);
				background=1;
			}
			else
			{
				str_array[wordCount][charCount] = str[i];
				charCount++;
			}
		}

        /*
        exit program
        */
		if(strcmp(str_array[0], "exit") == 0) 
		{
			repeat=0;
		}
		else if(str[0] == '#' || strlen(str) == 0) { 
            // when user enters nothing, so it reprompts
		}


        /*

        The cd command changes the working directory of smallsh.

        By itself - with no arguments - it changes to the directory specified in the HOME environment variable
        This is typically not the location where smallsh was executed from, unless your shell executable is located in the HOME directory, in which case these are the same.
        This command can also take one argument: the path of a directory to change to. Your cd command should support both absolute and relative paths.

        */
		else if(strcmp(str_array[0], "cd") == 0)
		{
			if(wordCount == 1)
			{
				sprintf(homeDir, "%s", getenv("HOME"));
				if (chdir(homeDir) != 0)
					printf("error --- cannot enter Home directory\n");	
			}
			else if(wordCount == 2)
			{
				strcpy(homeDir, str_array[1]);
				if (chdir(homeDir) != 0)
					printf("Change to %s directory failed\n", homeDir);
			}
			else
			{
				printf("Unexpected arguments with cd command\n");
			}
		}
        /*
        status
        */
		else if(strcmp(str_array[0], "status") == 0)
		{
			if(signal)
			{
				printf("terminated by signal %d\n", signal);
				signal=0;
			}
			else
			{
				printf("exit value %d\n", exitNum);
			}
		}

        /* 
        exec()
        */

		else 
		{
			if ((spawnpid = fork()) == -1)
			{
				perror("fork() error");
				exit(1);
			}
			else if (spawnpid == 0)
			{

				signalc.sa_handler = SIG_DFL;
				sigaction(SIGINT, &signalc, NULL);
				redirection = 0;
				for (i = 0; i < wordCount; i++)
				{
					if(strcmp(str_array[i], ">") == 0 || strcmp(str_array[i], "<") == 0)
						break;
					else
					{
						str_args[redirection] = str_array[i];
						redirection++;
					}			
				}

				while (i < wordCount)
				{
					if(strcmp(str_array[i], ">") == 0)
					{
						openFile = open(str_array[i+1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
						if (openFile == -1)
						{
							perror("targetopen()");
							exit(1);
						}
						result = dup2(openFile, 1);
						if (result == -1)
						{
							perror("source dup2()");
							exit(1);
						}
						i = i + 2;
					}
					else if(strcmp(str_array[i], "<") == 0)
					{
						openFile = open(str_array[i+1], O_RDONLY);
						if(openFile == -1)
						{
							perror("cannot open badfile for input");
							exit(1);
						}
						result = dup2(openFile, 0);
						if (result == -1)
						{
							perror("source dup2()");
							exit(1);
						}
						i = i + 2;
					}
						
				}
								
				str_args[redirection] = NULL;	
				if (execvp(str_args[0], str_args))
				{	
					printf("no such file or directory\n");	
					fflush(stdout);
					exit(2);
				}

				fcntl(openFile, F_SETFD, FD_CLOEXEC);	// sets the close on exec flag for the file descriptor, file descriptor to be automatically closed when any of the exec family6 function succeed. 	
			}
			else
			{
				if (background && backgroundProcesses) 
				{
					waitpid(spawnpid, &childExit, WNOHANG);
					printf("Background pid is %d\n", spawnpid);

					totalPids++;			
				}
				else 
				{
					waitpid(spawnpid, &childExit, 0);

					if (strcmp("kill", str_array[0]) == 0) {} 
					else if (WIFEXITED(childExit))
					{	
						signal=0;
						exitNum = WEXITSTATUS(childExit);
					}
					else
					{
						signal = WTERMSIG(childExit);
						printf("terminated by signal %d\n", signal);
					}
						
				}

		
			}

			while ((spawnpid = waitpid(-1, &childExit, WNOHANG)) > 0)
			{
				if(totalPids == 0){}
				else if (WIFEXITED(childExit))
				{
					signal=0;
					exitNum = WEXITSTATUS(childExit);
					printf("Background pid %d is done: exit value %d\n", spawnpid, exitNum);
				}
				else
				{
					signal = WTERMSIG(childExit);
					printf("Background pid %d is done: terminated by signal %d\n", spawnpid, signal);
				}
				totalPids--; 
				fflush(stdout);
			}		
		}
		background=0;
	}while(repeat); // repeat loop
	return 0; // false
}
