Compiling agap file 
gcc -std=gnu99 -pthread -o line_processor assign4.c
./line_processor
