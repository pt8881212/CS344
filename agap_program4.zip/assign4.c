/*
Pratiksha Aga
Assignment 4
CS 344 
*/

#include <stdbool.h> // boolean type and values
#include <assert.h> // verify program assertion
#include <unistd.h> // x open
#include <stdio.h> // lib used for input and output 
#include <stdlib.h> // lib used for functions involving memory allocation
#include <string.h> // lib used for strings
#include <pthread.h> // includes a large number of function such as 
// to create, join, and destroy threads


#define Size 1000 // the input will never be longer than 1000 characters (including the line separator)
#define Line 50 // The input for the program will never have more than 49 lines before the stop-processing line
#define STOP_MARKER "STOP\n" //must process input lines until it receives an input line that contains only the characters STOP, 
//i.e., STOP followed immediately by the line separator.

/*
code from "an example program"
Buffer 1
*/
char buffer_1[Size]; //  shared resource between input thread and line
pthread_mutex_t mutex_1= PTHREAD_MUTEX_INITIALIZER; //Initialize the muxtex for buffer 1
pthread_cond_t full_1 = PTHREAD_COND_INITIALIZER; // Initialzier condition variable for buffer 1
int count_1 = 0; // Number of items in the buffer

// Buffer 2
char buffer_2[Size]; // Shared resource between line separator thread and + thread
pthread_mutex_t mutex_2= PTHREAD_MUTEX_INITIALIZER; // Initialize the muxtex for buffer 1
pthread_cond_t full_2 = PTHREAD_COND_INITIALIZER; // Initialzier condition variable for buffer 1
int count_2 = 0; // Number of items in the buffer


// Buffer 3 
char buffer_3[Size]; // shared resource between + thread and output thread
pthread_mutex_t mutex_3 = PTHREAD_MUTEX_INITIALIZER; // Initialize the muxtex for buffer 3
pthread_cond_t full_3 = PTHREAD_COND_INITIALIZER; // Initialzier condition variable for buffer 1
int count_3 = 0;


/*
Get input from the user 
*/
char *get_user_input() {
   char input[Size]; // size 1000 
   fflush(stdout); // flushes the output buffer of a stream
   fflush(stdin);
   fgets(input, Size, stdin);
 
   return input;
}


/*
Get the next item from buffer 1
*/
char* get_buff_1(){
  // Lock the mutex before checking if the buffer has data
  pthread_mutex_lock(&mutex_1);
  while (count_1 == 0)
    // Buffer is empty. Wait for the producer to signal that the buffer has data
    pthread_cond_wait(&full_1, &mutex_1);
   char item[Size];
   strcpy(item, buffer_1);

   count_1--;
   // unlock the mutex
   pthread_mutex_unlock(&mutex_1);
   return item;
}

/*
 Function that the input thread will run.
 Get input from the user.
 Put the item in the buffer shared with the line separator thread
 code from "an example program"
*/
void *get_input(void *args) {
 
   for (int i = 0; i < Line; i ++) {
      // Get user input
      char *item = get_user_input();
      if (strcmp(item, "STOP\n") == 0) {
         put_buff_1(item);
         break;
      }
      put_buff_1(item);
   }
   return NULL;
}


/*
Put an item in Buffer 1
*/
void put_buff_1(char *item) {
  pthread_mutex_lock(&mutex_1); // Lock the mutex before putting the item in the buffer
  for(int i = 0; i <= strlen(item); i++)
   buffer_1[i] = item[i];

   
  // Put the item in the buffer
  // Increment the index where the next item will be put.
  count_1++;
  // Signal to the consumer that the buffer is no longer empty
  pthread_cond_signal(&full_1);
  // Unlock the mutex
  pthread_mutex_unlock(&mutex_1);

}

/*
Get the next item from buffer 2
 */
char *get_buff_2() {
   pthread_mutex_lock(&mutex_2); // Lock the mutex before checking if the buffer has data
   while (count_2 == 0)
      pthread_cond_wait(&full_2, &mutex_2); // Buffer is empty. Wait for the producer to signal that the buffer has data
   char item[Size];
   strcpy(item, buffer_2);

   count_2--;
   // unlock the mutex
   pthread_mutex_unlock(&mutex_2);
   return item;
}


/*
 Put an item in buff_2
*/
void put_buff_2(char *item) {
   pthread_mutex_lock(&mutex_2); // Lock the mutex before putting the item in the buffer
   strcpy(buffer_2, item);
   // Increment the index where the next item will be put.
   count_2++;
   pthread_cond_signal(&full_2); // Signal to the consumer that the buffer is no longer empty
   pthread_mutex_unlock(&mutex_2); // Unlock the mutex
}


/*
Replace line separator with space
*/
char *replaceLinetoSpace(char* item) {
   for (int i =0; i <= strlen(item); i++) {
      if(item[i] == '\n')
         item[i] = ' ';
   }
   return item;
}



/*
 Function that the line separator thread will run. 
 Consume an item from the buffer shared with the input thread.
 Print the item.
*/
void *lineSeparator(void *args) {
   char *item;
   //int i = 0;
   for (int i = 0; i < Line; i++) {
      item = get_buff_1();
      if (strcmp(item, "STOP\n") == 0) {
         put_buff_2(item);
         break;
      }    
      replaceLinetoSpace(item);
      put_buff_2(item);  
   }
   return NULL;
}

/*
 Put an item in buffer 3
 */
void put_buff_3(char * item) {
   pthread_mutex_lock(&mutex_3); // Lock the mutex before checking if the buffer has data
   strcpy(buffer_3, item);
   // Increment the index where the next item will be put.
   count_3++;
   pthread_cond_signal(&full_3);// Signal to the consumer that the buffer is no longer empty
   pthread_mutex_unlock(&mutex_3);// Unlock the mutex
}




/*
 Replace ++ 
*/
char *replace_Plus_Sign(char *item) {
   char buff2[strlen(item) - 1];
   while (strstr(item, "++") != NULL) {
      memset(buff2, '\0', sizeof(buff2));
      int i = 0;
      for(int i = 0; i < strlen(item); i++) {
         if (item[i] == '+' && item[i+1] == '+') {
            strncpy(buff2, item, i);
            strcat(buff2, "^");
            int j = i + 2;
            int s = strlen(buff2);
            while (j < strlen(item) - 1) {
                  buff2[s++] = item[j];
               j++;
            }
            s--;
            for (int j = 0; j <= s; j++) {
               if(buff2[j] == '\n')
                  buff2[j] = ' ';
            }
            memset(item, '\0', sizeof(item));
            strcat(item, buff2);
            break;
         }
      }
   }
   return item;
}

/*
 Replace even pair of plus signs with a caret.
 */
void *plustoCaret(void *args) {
   char *item;
   for (int i = 0; i < Line; i++) {
      item = get_buff_2();
      if (strstr(item, "STOP\n") != NULL) {
         put_buff_3(item);
         break;
      }
      replace_Plus_Sign(item);
      put_buff_3(item);
   }
   return NULL;
}

/*
 Get the next item from buffer 3
*/
char *get_buff_3() {
   pthread_mutex_lock(&mutex_3); // Lock the mutex before checking if the buffer has data
   while (count_3 == 0) 
      pthread_cond_wait(&full_3, &mutex_3); // Buffer is empty. Wait for the producer to signal that the buffer has data
   char item[Size];
   strcpy(item, buffer_3);
   
   count_3--;
   pthread_mutex_unlock(&mutex_3); // unlock the mutex

   return item;
}



/*
The “80 character line” to be written to standard output is defined as 
80 non-line separator characters plus a line separator.
*/


char *eightyChars(char *item) {
   char buffer[Size];
   memset(buffer, '\0', sizeof(buffer));
   size_t size = strlen(item);
   while (size >= 80) {
      printf("\n");
      fflush(stdout);
      write(1, item, 80);
      write(1, "\n", 2);
      int s = 79;
      for (int i = 0; i < strlen(item); i++) {
         if (item[s++] != '\0') {
            buffer[i] = item[s];
         }
         else
            break;
      }
      memset(item, '\0', sizeof(item));

      strcpy(item, buffer);

      size = size - 80;
   }
   return item;
}






void *output(void *agrs) {
   char *item;
   char buffer[Size];
   memset(buffer, '\0', sizeof(buffer));
   for (int i = 0; i < Line; i++) {
      item = get_buff_3();
      strcat(buffer, item);
         if (strstr(item, "STOP\n") != NULL) {
            break;
         }
         else {  
            eightyChars(buffer);
         }
   }
   return NULL;
}

// program execution
int main() {
      memset(buffer_1, '\0', sizeof(buffer_1));
      memset(buffer_2, '\0', sizeof(buffer_2));
      memset(buffer_3, '\0', sizeof(buffer_3));

   pthread_t input_t, lineSeparator_t, plusSign_t, output_t;

   pthread_create(&input_t, NULL, get_input, NULL);
   pthread_create(&lineSeparator_t, NULL, lineSeparator, NULL);
   pthread_create(&output_t, NULL, output, NULL);
   pthread_create(&plusSign_t, NULL, plustoCaret, NULL);

   pthread_join(input_t, NULL);
   pthread_join(lineSeparator_t, NULL);
   pthread_join(output_t, NULL);
   pthread_join(plusSign_t, NULL);

   return 0;
}

























