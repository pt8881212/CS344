
/*
Pratiksha Aga
CS 344 
Assignment 5
encrypt client
*/

#include <stdio.h> // for perror
#include <stdlib.h> // for exit
#include <string.h> // lib used for strings
#include <sys/types.h> // for pid_t
#include <unistd.h> // fork, execv
#include <sys/socket.h> // int type of width of at least 32 bits
#include <netdb.h> // network database operations

#define bufferSize 10000

// error function
void error(const char *msg) {
	perror(msg);
	exit(0);
}

// address struct
void addressStruct(struct sockaddr_in * address, int portNum, char *hostname) {
	memset((char*) address, '\0', sizeof(*address)); // clearing address struct
	address->sin_family = AF_INET; // network capable
	address->sin_port = htons(portNum); //  storing the port number

	// if there is not a host print the error
	struct hostent *info = gethostbyname(hostname);
	if (info == NULL) {
		fprintf(stderr, "error, no such host\n");
		exit(0);
	}
	memcpy((char*) &address->sin_addr.s_addr, info->h_addr_list[0], info->h_length);

}


int main(int argc, char *argv[]) {
	int clientSocketFD;
	int writtenChar;
	int readChar;
	struct sockaddr_in serverAddress;
	char buffer[bufferSize];
	char key[bufferSize];
	FILE *ciphertext, *keyFile;

	if (argc < 4) {
		fprintf(stderr, "usage: %s ciphertext key port\n", argv[0]);
		exit(0);
	}

	clientSocketFD = socket(AF_INET, SOCK_STREAM, 0); // create socket 
	if (clientSocketFD < 0)
		error("error opening socket");


	addressStruct(&serverAddress, atoi(argv[3]), "localhost"); // server address struct set up

	if (connect(clientSocketFD, (struct sockaddr*) &serverAddress, sizeof(serverAddress)) < 0) {
		close(clientSocketFD);
		error("error connecting");

	}
	// sending process name to enc_server that is coming from enc_client
	char *processN = "dec_client";
	if (send(clientSocketFD, processN, strlen(processN), 0) < 0) {
		fprintf(stderr, "error writing to socket\n"); 
		close(clientSocketFD);
		exit(2);
	}

	char msg[200]; // message from server
	if (recv(clientSocketFD, msg, sizeof(msg), 0) < 0) {
		fprintf(stderr, "error reading from socket\n");
		close(clientSocketFD);
		exit(1);
	}
	// checking to see if server rejects or accepts the connection 
	if (strstr(msg, "reject") != NULL) {
		fprintf(stderr, "error dec_server denied connection on port %d\n", atoi(argv[3]));
		close(clientSocketFD);
		exit(2); // if server rejects connection then exit
	}

	ciphertext = fopen(argv[1], "r");
	if (ciphertext == NULL) {
		close(clientSocketFD);
		fprintf(stderr, "error opening %s file\n!", argv[1]);
		exit(1);
	}
	memset(buffer, '\0', sizeof(buffer));
	fscanf(ciphertext, "%[^\n]", buffer);


	for (int i = 0; i < strlen(buffer); i++) {
		char str[] = "ABCDFEGHIJKLMNOPQRSTUVWXYZ ";
		int invalidChar = 0;
		for (int j = 0; j < 27; j++) {
			if (buffer[i] != str[j])
				invalidChar++;
		}
		if (invalidChar > 26) {
			close(clientSocketFD);
			fprintf(stderr, "invalid character in text\n");
			exit(1);
		}

	}
	fclose(ciphertext);


	keyFile = fopen(argv[2], "r");
	if (keyFile == NULL) {
		close(clientSocketFD);
		fprintf(stderr, "error opening %s file\n!", argv[1]);
		exit(1);
	}
	memset(key, '\0', sizeof(key));
	fscanf(keyFile, "%[^\n]", key);

	for (int i = 0; i < strlen(key); i++) {
		char str[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
		int invalidChar = 0;
		for (int j = 0; j < 27; j++) {
			if (key[i] != str[j])
				invalidChar++;
		}
		if (invalidChar > 26) {
			close(clientSocketFD);
			fprintf(stderr, "invalid character in text\n");
			exit(1);
		}
	}

	fclose(keyFile);

	if (strlen(key) < strlen(buffer)) {
		close(clientSocketFD);
		fprintf(stderr, "error key '%s' is too short\n", argv[2]);
		exit(1);
	}

	int ciphertextSize = strlen(buffer);
	writtenChar = send(clientSocketFD, &ciphertextSize, sizeof(ciphertextSize), 0);
	if (writtenChar < 0) {
		close(clientSocketFD);
		fprintf(stderr, "error writing to socket\n");
		exit(1);
	}
	writtenChar = send(clientSocketFD, buffer, strlen(buffer), 0);
	if (writtenChar < 0) {
		close(clientSocketFD);
		fprintf(stderr, "error writing to socket\n");
		exit(1);
	}
	if (writtenChar < strlen(buffer)) 
		printf("Warning! Not all data written to socket\n");

	writtenChar = send(clientSocketFD, key, strlen(key), 0);
	if (writtenChar < 0) {
		close(clientSocketFD);
		fprintf(stderr, "error writing to socket\n");
		exit(1);
	}
	if (writtenChar < strlen(buffer)) 
		printf("Warning! Not all data written to socket\n");


	memset(buffer, '\0', sizeof(buffer));
	readChar = recv(clientSocketFD, buffer, ciphertextSize, 0);
	if (readChar < 0) {
		fprintf(stderr, "dec_client: ERROR reading from sokcet\n");
	}
	printf("%s\n", buffer);

	close(clientSocketFD);

	return 0;
}






































































