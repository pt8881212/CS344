
/*
Pratiksha Aga
CS 344 
Assignment 5
encrypt server
*/

#include <stdio.h> // for perror
#include <stdlib.h> // for exit
#include <string.h> // lib used for strings
#include <sys/types.h> // for pid_t
#include <unistd.h> // fork, execv
#include <signal.h> // signals
#include <fcntl.h> //file control option use fcntl()
#include <sys/wait.h> // pit_t wait returns the process id of the terminated child waitpid()
#include <sys/socket.h> // int type of width of at least 32 bits
#include <netinet/in.h> //contain the wildcard IPv6 address -- source -- pubs.opengroup.org


#define buffer 10000

// error message
void error(const char *msg) {
  perror(msg);
  exit(1);
}
// socket addresses struct
void addressStruct(struct sockaddr_in* address, int portNum){

  memset((char*) address, '\0', sizeof(*address));

  address->sin_family = AF_INET; // network competent
  address->sin_port = htons(portNum); // storing the port number
  address->sin_addr.s_addr = INADDR_ANY; // client being able to connect to this server at any address
}

//Receiving ciphertext and the key from dec_client and dec data and sending it to plaintext to dec_client
void decrypt(int connectionSocket, char* ciphertext, char* key, char* plaintext, char*accept, char* reject) {
	int readChar;
	int writtenChar;
	char processN[25];
	memset(processN, '\0', sizeof(processN));
	// if it's from dec_client process then accept or else reject
	readChar = recv(connectionSocket, processN, sizeof(processN), 0);
	if (readChar < 0)
		error("error reading from socket");
	if (strstr(processN, "dec_client") != NULL) {
		writtenChar = send(connectionSocket, accept, sizeof(accept), 0);
		if (writtenChar < 0)
			error("error writing to socket");
	}
	else {
		writtenChar = send(connectionSocket, reject, sizeof(reject), 0);
		if (writtenChar < 0)
			error("error writing to socket");
		fprintf(stderr, "Connection from unexpected program\n");
		exit(1);
	}

	// reading the size of the ciphertext
	int ciphertextSize = 0;
	readChar = recv(connectionSocket, &ciphertextSize, sizeof(ciphertextSize), 0);
	if (readChar < 0)
		error("error reading from socket");
	// reading the ciphertext from the socket
	memset(ciphertext, '\0', sizeof(ciphertext));
	readChar = recv(connectionSocket, ciphertext, ciphertextSize, 0);
	if (readChar < 0)
		error("error reading from socket");
	// reading the key from the socket
	memset(key, '\0', sizeof(key));
	readChar = recv(connectionSocket, key , ciphertextSize, 0);
	if (readChar < 0)
		error("error reading from socket");


	memset(plaintext, '\0', sizeof(plaintext));
	for (int i = 0; i < strlen(ciphertext); i++) {
		int encData1;
		int encData2;
		int sumData = 0;
		char characters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
		for (int j = 0; j < 27; j++) {
			if (ciphertext[i] == characters[j])
				encData1 = j;
			if (key[i] == characters[j])
				encData2 = j;
		}
		sumData = encData1 - encData2;
		if(sumData < 0)
			sumData += 27;
		plaintext[i] = characters[sumData];
	}
	printf("%s\n", plaintext);	

	writtenChar = send(connectionSocket, plaintext, ciphertextSize, 0);
	if (writtenChar < 0)
		error("error writing to socket");
	close(connectionSocket);
}

int main(int argc, char* argv[]) {
	char plaintext[buffer];
	char key[buffer];
	char ciphertext[buffer];
	char acceptC[] = "accept";
	char rejectC[] = "reject";
	int connectionSocket;
	int readChar;
	int writtenChar;
	int status;
	int processNum = 0;
	pid_t pid;

	struct sockaddr_in serverAddress, clientAddress;
	socklen_t sizeOfClientInfo = sizeof(clientAddress);

	if (argc < 2) {
		fprintf(stderr, "USAGE: %s listening_port\n", argv[0]);
		exit(0);
	}

	int listenSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (listenSocket < 0) {
		error("error opening socket");
	}

	addressStruct(&serverAddress, atoi(argv[1]));

	if (bind(listenSocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0) {
		close(listenSocket);
		error("error on binding");
	}

	listen(listenSocket, 5);

	while (1) {
		connectionSocket = accept(listenSocket, (struct sockaddr*)&clientAddress, &sizeOfClientInfo);
		if (connectionSocket < 0) {
			close(listenSocket);
			error("error on accept");
		}
		if (processNum < 5) { // total of 5 connections allowed
			pid = fork();

				if(pid == -1){
						error("error on fork()");
					}
					else if(pid == 0){
						close(listenSocket);
						decrypt(connectionSocket, ciphertext, key, plaintext, acceptC, rejectC);
						exit(0);
					}
					else
					processNum++;
		}
		else fprintf(stderr,"wait for completion\n");
		for (int i = 0; i < 5; i++) {
			if(waitpid(-1, &status, WNOHANG) == -1)
				fprintf(stderr,"error on waitpid()\n");
			if (WIFEXITED(status))
				processNum--;
		}
	}

	close(listenSocket);
	return 0;
}







