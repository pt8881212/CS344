
/*
Pratiksha Aga
CS 344 
Assignment 5
keygen
*/

#include <stdio.h> // for perror
#include <stdlib.h> // for exit
#include <string.h> // lib used for strings
#include <time.h> // header file containing time and date function declarations

int main(int argc, char *argv[]) {

   if (argc < 2) {
      // must provide keygen and then length of key
      fprintf(stderr, "Length of key not provided!\n");
      fprintf(stderr, "Provide keylength followed by keygen\n");
      exit(1);
   }

   // for length of key that is specified by the user
   // generated key
   int keylength = atoi(argv[1]);
   char key[atoi(argv[1])];
   memset(key, '\0', sizeof(key));

   // for negative errors, only accepting keylength greater than 0
   if (keylength <= 0) {
      fprintf(stderr, "Error, keylength cannot be negative, only greater than 0\n");
      exit(1);
   }

   // generate random, time(NULL) for setting the seed based on the current time
   srand(time(NULL));

   // storing every random character into character array of key
   int i;
   char randomChar;
   for (i = 0; i < keylength; i++) {
     randomChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ "[rand() % 27];
     key[i] = randomChar;

   }
   // null exit characters of the key string
   key[keylength] = '\0';
   printf("%s\n", key);
   return 0;
}





















